<?php $__env->startSection('content'); ?>
    <!-- batas 1 -->
    <div class="row">
        <div class="col-lg-8 p-r-0 title-margin-right">
            <div class="page-header">
                <div class="page-title">
                    <h1>Edit Blok</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End batas 1 -->
    <?php if(\Session::has('notif')): ?>
        <div class="alert alert-dark" align="center">
            <?php echo \Session::get('notif'); ?>

        </div>
    <?php endif; ?>
    <!-- error -->
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <!-- end error -->
    <!-- Table -->
    <div class="row">
        <div class="col-lg-12">
            
            <div class=" shadow">
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Kembali</li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('blok', [])); ?>"> <i class="ti-arrow-left"
                                aria-hidden="true"></i></a></li>
                    
                </ol>
            </div>
            
            <div class="card">
                <form action="/blok/<?php echo e($edit->id); ?>/update" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-row">
                        <div class="col-12 col-sm-12">
                            <label class="small mb-1" for="inputPassword">BLOK</label>
                            <input type="text" name="blok" value="<?php echo e($edit->blok); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                        <input type="submit" class="btn btn-success" value="Update">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Table -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\KP\PERUMAHAN\PERUMAHAN\resources\views/blok/edit.blade.php ENDPATH**/ ?>