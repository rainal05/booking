<?php $__env->startSection('content'); ?>
    <!-- batas 1 -->
    <div class="row">
        <div class="col-lg-8 p-r-0 title-margin-right">
            <div class="page-header">
                <div class="page-title">
                    <h1>SYARAT BOOKING RUMAH
                    </h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End batas 1 -->
    <?php if(\Session::has('notif')): ?>
        <div class="alert alert-dark" align="center">
            <?php echo \Session::get('notif'); ?>

        </div>
    <?php endif; ?>
    <!-- error -->
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <!-- end error -->
    <!-- Table -->
    <div class="row">
        <div class="col-lg-12">
            
            <div class=" shadow">
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('/data/booking', [])); ?>"> <i
                                class='fa fa-arrow-circle-left'></i> Data Booking</a></li>
                    
                </ol>
            </div>
            
            <div class="card">
                <div class="user-profile">
                    <div class="row">
                        
                        <div class="col-lg-12">
                            <div class="user-profile-name">
                                <?php echo e($isi->rumah->type); ?>-<?php echo e($isi->rumah->blok->blok ?? ''); ?><?php echo e($isi->rumah->no ?? ''); ?>

                            </div>
                            <hr>
                            <?php $__currentLoopData = $isi->syarat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="val-website"><b>KTP</b> <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-3">
                                        <span class="phone-number"><a href="<?php echo e(url('/syarat/' . $item->ktp)); ?>"
                                                target="_blank"><i class="ti-download"></i>
                                                View</a>
                                        </span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="val-website"><b>KK</b> <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-3">
                                        <span class="phone-number"><a href="<?php echo e(url('/syarat/' . $item->kk)); ?>"
                                                target="_blank"><i class="ti-download"></i>
                                                View</a>
                                        </span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="val-website"><b>SURAT NIKAH/BELUM</b> <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-3">
                                        <span class="phone-number"><a href="<?php echo e(url('/syarat/' . $item->surat_nikah)); ?>"
                                                target="_blank"><i class="ti-download"></i>
                                                View</a>
                                        </span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="val-website"><b>FOTO</b> <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-3">
                                        <span class="phone-number"><a href="<?php echo e(url('/syarat/' . $item->poto)); ?>"
                                                target="_blank"><i class="ti-download"></i>
                                                View</a>
                                        </span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="val-website"><b>NPWP</b> <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-3">
                                        <span class="phone-number"><a href="<?php echo e(url('/syarat/' . $item->npwp)); ?>"
                                                target="_blank"><i class="ti-download"></i>
                                                View</a>
                                        </span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="val-website"><b>SLIP GAJI</b> <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-3">
                                        <span class="phone-number"><a href="<?php echo e(url('/syarat/' . $item->slip_gaji)); ?>"
                                                target="_blank"><i class="ti-download"></i>
                                                View</a>
                                        </span>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="val-website"><b>REKENING KORAN </b><span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-3">
                                        <span class="phone-number"><a href="<?php echo e(url('/syarat/' . $item->rek_koran)); ?>"
                                                target="_blank"><i class="ti-download"></i>
                                                View</a>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <form action="/data/syarat/up/<?php echo e($isi->id); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                <div class="form-group row">
                                    <label class="col-lg-4 col-form-label" for="val-select2"><b>STATUS</b> <span
                                            class="text-danger">*</span></label>
                                    <div class="col-lg-4">
                                        <select name="status" class="form-control" id="val-skill" name="val-skill">
                                            <option value="Menunggu Verifikasi"
                                                <?php if($isi->status == 'Menunggu Verifikasi'): ?> selected <?php endif; ?>>
                                                Menunggu Verifikasi</option>
                                            <option value="Terverifikasi" <?php if($isi->status == 'Terverifikasi'): ?> selected <?php endif; ?>>
                                                Terverifikasi</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="form-group row">
                                    <div class="col-lg-8 ml-auto">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </form>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Table -->

    <!-- Modal tambah -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Lengkapi Syarat Booking Rumah</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="<?php echo e(url('/booking/syarat/up')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="booking_id" value="<?php echo e($isi->id); ?>">
                        <div class="form-row">
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress"><b>KTP</b></label>
                                <input type="file" name="ktp" class="form-control">
                            </div>
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress"><b>KK</b></label>
                                <input type="file" name="kk" class="form-control">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress"><b>SURAT NIKAH / BELUM NIKAH</b></label>
                                <input type="file" name="surat_nikah" class="form-control">
                            </div>
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress"><b>FOTO</b></label>
                                <input type="file" name="poto" class="form-control">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress"><b>NPWP</b></label>
                                <input type="file" name="npwp" class="form-control">
                            </div>
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress"><b>SLIP GAJI</b></label>
                                <input type="file" name="slip_gaji" class="form-control">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-12 col-sm-12">
                                <label for="inputEmailAddress"><b>REKENING KORAN</b></label>
                                <input type="file" name="rek_koran" class="form-control">
                            </div>
                        </div>
                        <label class="form-label">
                            <span class="badge border-dark border-1 text-dark"><i>Note : Scan File Dan Upload
                                    Dalam Bentuk PDF/JPEG/JPG</i></span>
                        </label>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <button type="reset" class="btn btn-secondary">Reset</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <!-- Modal tambah -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RAIN\KP\PERUMAHAN\resources\views/data-booking/data-syarat.blade.php ENDPATH**/ ?>