<?php $__env->startSection('content'); ?>
    <!-- batas 1 -->
    <div class="row">
        <div class="col-lg-8 p-r-0 title-margin-right">
            <div class="page-header">
                <div class="page-title">
                    <h1>Edit Perumahan</h1>
                </div>
            </div>
        </div>
    </div>
    <!-- End batas 1 -->
    <?php if(\Session::has('notif')): ?>
        <div class="alert alert-dark" align="center">
            <?php echo \Session::get('notif'); ?>

        </div>
    <?php endif; ?>
    <!-- error -->
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <!-- end error -->
    <!-- Table -->
    <div class="row">
        <div class="col-lg-12">
            
            <div class=" shadow">
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Kembali</li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('perumahan', [])); ?>"> <i class="ti-arrow-left"
                                aria-hidden="true"></i></a></li>
                    
                </ol>
            </div>
            
            <div class="card">
                <form action="/perumahan/<?php echo e($edit->id); ?>/update" method="POST" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-row mt-4">
                        <div class="col-6 col-sm-6">
                            <label class="small mb-1" for="inputEmailAddress">Nama Blok</label>
                            <select name="blok_id" class="multisteps-form__select form-control">
                                <option value="">-- PILIH --</option>
                                <?php $__currentLoopData = $blok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->blok); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-6 col-sm-6">
                            <label class="small mb-1" for="inputEmailAddress">No</label>
                            <input type="number" name="no" value="<?php echo e($edit->no); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="form-row mt-4">
                        <div class="col-12 col-sm-12">
                            <label class="small mb-1" for="inputPassword">Harga</label>
                            <input type="number" name="harga" value="<?php echo e($edit->harga); ?>" class="form-control">
                        </div>
                    </div>
                    <div class="form-group d-flex align-items-center justify-content-between mt-4 mb-0">
                        <input type="submit" class="btn btn-success" value="Update">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Table -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\KP\PERUMAHAN\PERUMAHAN\resources\views/rumah/edit.blade.php ENDPATH**/ ?>