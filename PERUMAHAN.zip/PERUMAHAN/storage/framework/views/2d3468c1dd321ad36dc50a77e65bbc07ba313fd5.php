<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="Author" content="">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <!-- TITLE -->
    <title>Laporan Terbooking - Perumahan Mentari Residence</title>
    <!-- ok -->
    <link href="<?php echo e(asset('admin')); ?>/assets/css/1.css" rel="stylesheet" />
    <link href="<?php echo e(asset('admin')); ?>/assets/css/2.css" rel="stylesheet">
    <!-- HEADER -->
</head>

<body onload="window.print()">
    <table border="0" style="width: 100%">
        <!-- <tbody> -->
        <tr>
            <td class="auto-style1">
                <center>
                    <h2 class="auto-style1">Laporan Terbooking - Perumahan Mentari Residence</h2>
                    
                    
                </center>
            </td>
        </tr>
        </tbody>
    </table>
    <!-- HEADER -->

    <!-- BODY -->
    
    <table width="100%" class="tblcms2">
        <tbody>
            <tr>
                <th class="th_border cell">No</th>
                <!--h <th class="th_border cell">Id Admin </th> h-->
                <th align="center" class="th_border cell">Nama Blok</th>
                <th align="center" class="th_border cell">Status </th>
            </tr>

        </tbody>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="event2">
                    <td align="center" width="50"><?php echo e($loop->iteration); ?></td>
                    <td align="center"><?php echo e($row->type ?? '-'); ?>-<?php echo e($row->blok->blok ?? ''); ?><?php echo e($row->no ?? ''); ?></td>
                    <td align="center">
                        <?php if($row['qty'] == '1'): ?>
                            Tersedia
                        <?php elseif($row['qty'] == '0'): ?>
                            Terbooking
                        <?php else: ?>
                            Terbooking Double
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td class="text-center" colspan="3" align="center">Data Terbooking Kosong!!!</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <!-- BODY -->
    <!-- FOOTER -->
    

</body>

</html>
<?php /**PATH D:\RAIN\PERUMAHAN\resources\views/laporan/terbooking.blade.php ENDPATH**/ ?>